<script>
document.addEventListener('DOMContentLoaded', function() {
    var container = document.querySelector('.forecast-container');
    var cards = document.querySelectorAll('.forecast-card');
    var cardWidth = cards[0].offsetWidth; // Ширина карточек
    var index = 0;

    document.getElementById('arrow-left').addEventListener('click', function() {
        if (index > 0) {
            index--;
            container.style.transform = 'translateX(-' + (index * cardWidth) + 'px)';
        }
    });

    document.getElementById('arrow-right').addEventListener('click', function() {
        if (index < cards.length - 1) {
            index++;
            container.style.transform = 'translateX(-' + (index * cardWidth) + 'px)';
        }
    });
});
</script>