const cities = [
    { name: "Москве", temp: 23 },
    { name: "Санкт-Петербурге", temp: 21 },
    { name: "Новосибирске", temp: 22 }
];

let currentCity = '';
let currentTemp = 0;
let currentIndex = 0;

// Функция для выбора случайного города
function getRandomCity() {
    currentIndex = Math.floor(Math.random() * cities.length);
    currentCity = cities[currentIndex].name;
    currentTemp = cities[currentIndex].temp;
    document.getElementById('city').textContent = currentCity;
}

// Функция для обработки формы
function handleFormSubmit(event) {
    event.preventDefault();
    
    const userTemp = parseInt(document.getElementById('temp').value);
    const resultDiv = document.getElementById('result');
    
    if (userTemp === currentTemp) {
        resultDiv.textContent = `Верно! Температура в ${currentCity} действительно ${currentTemp}°C.`;
        cities.splice(currentIndex, 1); // Убираем угаданный город из массива
        if (cities.length > 0) {
            getRandomCity();
        } else {
            resultDiv.textContent += ' Вы угадали все города!';
        }
    } else {
        resultDiv.textContent = `Неверно. В ${currentCity} сейчас ${currentTemp}°C. Попробуйте еще раз.`;
        // Выбираем новый случайный город, если ответ неверный
        getRandomCity();
    }
}

// Инициализация первой попытки
getRandomCity();
document.getElementById('weatherForm').addEventListener('submit', handleFormSubmit);